<?php
class home{
    function index(){
        include 'App/views/index.html';
    }
}
