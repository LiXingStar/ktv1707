<?php
class categorymanage{

    function index(){
         $title = '分类管理';
        include 'App/views/categorymanage.html';
    }
    function show(){

    }
    function upload(){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            if(!file_exists('Public/upload')){
                mkdir('Public/upload');
            }
            $data = date('y-m-d');
            if(!file_exists('Public/upload/'.$data)){
                mkdir('Public/upload/'.$data);
            }
            $path = 'Public/upload/'.$data.'/'.$_FILES['file']['name'];

            if( move_uploaded_file($_FILES['file']['tmp_name'],$path)){
                echo '/ktv1707/'.$path;
            }

        }
    }
    function update(){

    }
    function insert(){

    }
}