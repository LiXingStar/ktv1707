$(function(){
   let user = $('#user');
   let pass = $('#pass');
   let sub = $(':submit');
   let form =$('form');
   sub.on('click',function(){
       // let data = {user: user.val(),pass:pass.val()};
       let data = form.serializeArray();
       let obj = {};
       let dataStr = form.serialize();
       /*
       *  [
       *   {name:'user',value:'damin'},
       *   {name:'pass',value:'12345'}
       *  ]
       *
       * {
       *   user:'admin',pass:'12345'
       * }
       *  user=admin&pass=12345
       * */
       $.each(data,function(i,v){
           obj[v.name] = v.value;
       })


       $.ajax({
           url:'/ktv1707/index.php/login/check',
           data:obj,
           success:function(data){
               if(data=='ok'){
                   location.href = '/ktv1707/index.php/gamemanage';
               }else if(data=='error'){
                 alert('fail');
               }
           }

       })

       return false;
   })

})